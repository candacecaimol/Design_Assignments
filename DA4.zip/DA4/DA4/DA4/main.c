/*
 * DA4.c
 *
 * Created: 4/7/2016 7:21:32 PM
 * Author : user
 */ 

#define F_CPU 8000000UL		//XTAL = 8MHz
#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
	//////////////////////////////////////////////////////////////////////////////////////////
	///////////////////// TIMER0 used for RED LED ////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
    DDRD |= (1 << PORTD6);	//enable PD6 (OC0A) as output 
	unsigned int r = 0x19;	//10% duty cycle for timer0
	TCCR0A |= (1 << COM0A1);	//noninverting mode (high at bottom, low at TOP)
	TCCR0A |= (1 << WGM01) | (1 << WGM00);		//fast PWM mode
	TCCR0B |= (1 << CS00); //no prescaler 
	
	/////////////////////////////////////////////////////////////////////////////////////////
	//////////////////// TIMER1 used for BLUE LED ///////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////
	DDRB |= (1 << PORTB1);	//enable PB1 (OC1A) as output
	unsigned int b = 0x19;	//10% duty cycle for timer1
	TCCR1A |= (1 << COM1A1);	//noninverting mode (high at bottom, low at TOP)
	TCCR1A |= (1 << WGM10);		//fast PWM mode (8bit); top is 0x00FF
	TCCR1B |= (1 << CS10); //no prescaler
	
	///////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////// TIMER2 used for GREEN LED /////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	DDRB |= (1 << PORTB3);	//enable PB3 (OC2A) as output
	unsigned int g = 0x19;	//10% duty cycle for timer2
	TCCR2A |= (1 << COM2A1);	//noninverting mode (high at bottom, low at TOP)
	TCCR2A |= (1 << WGM21) | (1 << WGM20);		//fast PWM mode top is 0xFF
	TCCR2B |= (1 << CS20); //no prescaler 
	 
    while (1)		//makes sequence loop forever
    {
		while (r < 0xE5)	//while < 90% DC in red LED (increase brightness)
		{
			OCR0A = r;		//set to desired duty cycle value
			_delay_ms(200);		//delay for 200ms
			while (g < 0xE5)	//while < 90% DC in green LED (increase brightness)
			{
				OCR2A = g;		//set to desired duty cycle value
				_delay_ms(200);	//delay for 200 ms
				while (b < 0xE5)	//while < 90% DC in blue LED (increase brightness)
				{
					OCR1A = b;		//set to desired duty cycle value
					_delay_ms(200);	//delay for 200 ms
					b += 0x0A;		//increase DC by 10% in blue LED until 90% DC
				}
				g += 0x0A;		//increase DC by 10% in green until 90% DC
			}
			r += 0x0A;		//increase DC by 10% in red LED until 90% DC
		}
		while (r > 0x19)	//while > 10% DC in red LED
		{
			OCR0A = r;		//set to desired duty cycle value
			_delay_ms(200);		//delay for 200 ms
			while (g > 0x19)	//while > 10% DC in green LED
			{
				OCR2A = g;		//set to desired duty cycle value
				_delay_ms(200);		//delay for 200 ms
				while (b > 0x19)	//while > 10% DC in blue LED
				{
					OCR1A = b;		//set to desired duty cycle value
					_delay_ms(200);	//delay for 200 ms
					b -= 0x0A;		//decrease DC by 10% in blue LED until 10% DC
				}
				g -= 0x0A;		//decrease DC by 10% in green LED until 10% DC
			}
			r -= 0x0A;		//decrease DC by 10% in red LED until 10% DC
		}
    }
}

