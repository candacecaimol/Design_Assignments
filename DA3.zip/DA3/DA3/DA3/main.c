/*
 * DA3.c
 *
 * Created: 3/28/2016 1:58:13 PM
 * Author : candace.caimol
 */ 

#include <avr/io.h>
#include <stdint.h>				//used for uint8_t
//#include <util/setbaud.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#define F_CPU 16000000UL		//clock speed
#define BAUD 9600				//baud (used to calculate baud rate)
#define UBRR_VAL F_CPU/16/BAUD-1	//calculated baud rate

void Usart_Init(void);		//function prototypes
void Usart_Send(char*);
void ADC_Init(void);
void Timer1_Start(void);

//unsigned char test_string[21] = "I HOPE THIS WORKS\r\n";

int main(void)
{
	DDRC = (0 << PC0);		//set PC0 as input (used for temp sensor output)
	
	Usart_Init();		//initialize usart config
	ADC_Init();			//initialize ADC config
	sei();				//enable interrupts
	Timer1_Start();		//starts timer 
	while (1) 
	{
						//what for timer overflow
	}
	return 0;
}

void Usart_Init(void)
{
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);	//enable USART transmitter and receiver
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);	//character size is 8 bits, asynchronous
	UBRR0H = 0;			//higher byte of baud rate
	UBRR0L = 0x67; //UBRR_VAL;	//lower byte of baud rate
}

void Usart_Send(char *ch)
{
	while (*ch != '\0')		//while not NULL
	{
		while (! (UCSR0A & (1 << UDRE0)));		//wait until the transmit buffer is ready to receive data
		UDR0 = *ch;		//send character to output buffer
		ch++;			//set to point to next character 
	}
}

void ADC_Init(void)
{
	ADMUX |= (1 << REFS0) | (1 << REFS1);		//Vref = 1.1V; right adjust for 8 bit resolution
	ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); //128 prescaler for 16Mhz
	ADCSRA = (1 << ADEN);		//enable ADC
}

void Timer1_Start(void)
{
	TCNT1 = 49910;
	TCCR1A = 0;			//normal mode
	TCCR1B = 5;			//prescaler 1024
	TIMSK1 = (1 << TOIE1);		//OV interrupt
}

ISR (TIMER1_OVF_vect)
{
	TCCR1B = 0;
	TIFR1 = 1;
	
	int get_temp;		//gets temperature reading from ADC
	float convert_to_float;	//converts temperature reading to float value
	int whole_num;		//whole number part of temperature
	int dec_num;		//decimal part of number
	
	char output_string[21] = "Current Temperature: ";		//main label
	char degrees_F[6] = "�F\r\n";		//displays units (Fahrenheit)
	
	ADCSRA |= (1 << ADSC);		//convert
	
	while ((ADCSRA & (1 << ADSC)))
	{
			//loop until conversion is complete
	}
	get_temp = ADC;		//get ADC value
	convert_to_float = (float) get_temp * (1.1 / 1024) / 0.01; //ADC = Vin*1024/Vref
	whole_num = (int) convert_to_float;		//value to right side of decimal point
	convert_to_float = convert_to_float - whole_num;	//leaves decimal part of number
	dec_num = (int) (convert_to_float * 10);	//decimal to displayable format
	
	Usart_Send(output_string);	//displays "Current Temperature: "
	printf("%d", whole_num);	//displays whole number part of temperature
	printf(".%d", dec_num);		//displays decimal point and decimal portion of temperature
	Usart_Send(degrees_F);		//displays units in Fahrenheit
	
	Timer1_Start();
}

