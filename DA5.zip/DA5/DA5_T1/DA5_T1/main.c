/*
 * DA5.c
 *
 * Created: 4/18/2016 2:51:31 PM
 * Author : candace.caimol
 */ 

#define F_CPU 8000000UL		//XTAL = 8MHz 

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
volatile uint8_t ADCvalue;

///////////////////////////////////////////////////////////////////////
//////////////DC MOTOR + POTENTIOMETER CODE////////////////////////////
///////////////////////////////////////////////////////////////////////

void ADC_init(void)
{
	ADMUX = 0; // use ADC0
	ADMUX |= (1 << REFS0) | (1 << REFS1); // use 1.1V as the reference
	ADMUX |= (1 << ADLAR); // Right adjust for 8 bit resolution
	ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (0 << ADPS0); // 64 prescale for 16Mhz
	ADCSRA |= (1 << ADATE); // Set ADC Auto Trigger Enable
	ADCSRB = 0; // 0 for free running mode
	ADCSRA |= (1 << ADEN); // Enable the ADC
	ADCSRA |= (1 << ADIE); // Enable Interrupts
	ADCSRA |= (1 << ADSC); // Start the ADC conversion
}

ISR(ADC_vect)				//interrupt vector (occurs when conversion is finished)
{
	ADCvalue = ADCH;		//higher byte of ADC read in as accepted ADC value 
}

int main(void)
{
    DDRC = 0;		//PORTC set to all inputs (for PC0)
    DDRD = 0xFF;	//PORTB set to all outputs
    		
    //int get_ADC;	//holds ADC value
	int i;
    float ADC_float;	//converted value of ADC
    		
    ADC_init();			//initialize ADC configuration
	TCCR0A |= (1 << COM0A1) |(1 << COM0A0) | (1 << WGM00);		//toggle on compare match, CTC mode
	TCCR0B |= (1 << CS00);	//PWM phase correct, prescaler 1
	sei();
	while (1) 
    {  
		ADC_float = (float) ADCvalue * (1.1 / 1024.0);		//ADC = Vin *1024 / Vref 
		i = ADC_float * 10;			//values put in through trial and error 
		OCR0A = i * 250;			//range of 442mV * 148.26 k = 65535 (add starting value of 8mV) 
    }
}












