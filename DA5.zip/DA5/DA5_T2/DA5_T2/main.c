#define F_CPU 8000000UL //XTAL = 8MHZ
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

volatile uint8_t ADCvalue;
volatile float i;

///////////////////////////////////////////////////////////
//////////////////STEPPER MOTOR + POTENTIOMETER////////////
///////////////////////////////////////////////////////////

void delay(int delayVal)			//delay function
{
	int n;							//used to place hold delay counter
	for (n = 0; n < delayVal; n++)		//delay for full length of delay time
	_delay_ms(1);						//delay 1ms at a time
}

void ADC_init(void)
{
	ADMUX = 0; // use ADC0
	ADMUX |= (1 << REFS0) | (1 << REFS1); // use 1.1V as the reference
	ADMUX |= (1 << ADLAR); // Right adjust for 8 bit resolution
	ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // 128 prescale for 16Mhz
	ADCSRA |= (1 << ADATE); // Set ADC Auto Trigger Enable
	ADCSRB = 0; // 0 for free running mode
	ADCSRA |= (1 << ADEN); // Enable the ADC
	ADCSRA |= (1 << ADIE); // Enable Interrupts
	ADCSRA |= (1 << ADSC); // Start the ADC conversion
}

ISR(ADC_vect)
{
	ADCvalue = ADCH;			//higher by of ADC is passed
}

int main()
{
	DDRC = 0x00;				//PORTC enabled as input
	DDRB = 0xFF;				//PORTD enabled as output
	
	ADC_init();					//initialize ADC
	sei();						//interrupts enabled
	

	while(1)
	{
		i = (ADCvalue * .200) + 10;		//ADC value converted to get delay time (changes with potentiometer size)
		PORTB = 0X06;					//1st step
		delay(i);						//call delay function
		PORTB = 0x03;					//2nd step
		delay(i);						//call delay function
		PORTB = 0x09;					//3rd step
		delay(i);						//call delay function
		PORTB = 0x0C;					//4th step
		delay(i);
	}
	return 0;
}


