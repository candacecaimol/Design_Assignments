#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


volatile uint8_t ADCvalue;
volatile float i;


void delay(int delayVal)
{
	int n;
	for (n = 0; n < delayVal; n++)
	_delay_ms(1);
}

void ADC_init(void)
{
	ADMUX = 0; // use ADC0
	ADMUX |= (1 << REFS0) | (1 << REFS1); // use AVcc as the reference
	ADMUX |= (1 << ADLAR); // Right adjust for 8 bit resolution
	ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // 128 prescale for 16Mhz
	ADCSRA |= (1 << ADATE); // Set ADC Auto Trigger Enable
	ADCSRB = 0; // 0 for free running mode
	ADCSRA |= (1 << ADEN); // Enable the ADC
	ADCSRA |= (1 << ADIE); // Enable Interrupts
	ADCSRA |= (1 << ADSC); // Start the ADC conversion
}

ISR(ADC_vect)
{
	ADCvalue = ADCH;
}

int main()
{
	
	ADC_init();

	//PORTD pins as input
	DDRD = 0x00;
	//Enable internal pull ups
	PORTD = 0xFF;
	//Set PORTB1 pin as output
	DDRB = 0xFF;
	//TOP = ICR1;
	//output compare OC1A 8 bit non inverted PWM
	//Clear OC1A on Compare Match, set OC1A at TOP
	//Fast PWM
	//ICR1 = 20000 defines 50Hz pwm
	ICR1 = 20000;
	TCCR1A|=(0<<COM1A0)|(1<<COM1A1)|(0<<COM1B0)|(0<<COM1B1)|(0<<FOC1A)|(0<<FOC1B)|(1<<WGM11)|(0<<WGM10); //TCCR1A = 0x82
	TCCR1B|=(0<<ICNC1)|(0<<ICES1)|(1<<WGM13)|(1<<WGM12)|(0<<CS12)|(1<<CS11)|(0<<CS10);
	//TCCR1B = 0x1A
	//start timer with prescaler 8
	//min is 400
	//max is 2400
	
	sei();
	while(1)
	{
		//float ADC_float = (float) ADCvalue * (1.1 / 1024) * 0.01;		//ADC = Vin *1024 / Vref
		i = ADCvalue ;
		OCR1A = i * 40.62 + 600;			//range of 442mV * 148.26 k = 65535 (add starting value of 8mV)
	}
}

