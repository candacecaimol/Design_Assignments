/*
 * DA6.c
 *
 * Created: 4/29/2016 10:17:43 AM
 *  Author: caimol
 */ 


#define F_CPU 8000000UL
#include <avr/io.h> //standard AVR header
#include <util/delay.h> //delay header
#include <avr/interrupt.h>
#define LCD_DPRT PORTD //LCD DATA PORT
#define LCD_DDDR DDRD //LCD DATA DDR
#define LCD_DPIN PIND //LCD DATA PIN
#define LCD_CPRT PORTB //LCD COMMANDS PORT
#define LCD_CDDR DDRB //LCD COMMANDS DDR
#define LCD_CPIN PINB //LCD COMMANDS PIN
#define LCD_RS 0 //LCD RS
#define LCD_RW 1 //LCD RW
#define LCD_EN 2 //LCD EN

//****************************************************************
void lcdCommanda (unsigned char cmnd)
{
	LCD_DPRT = cmnd; //send cmnd to data port
	LCD_CPRT &= ~(1<<LCD_RS); //RS = 0 for command
	LCD_CPRT &= ~(1<<LCD_RW); //RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN); //EN = 1 for H-to-L pulse
	_delay_us(1); //wait to make enable wide
	LCD_CPRT &= ~(1<<LCD_EN); //EN = 0 for H-to_L pulse
	_delay_us(100); //wait to make enable wide
}

void lcdData(char data)
{
	LCD_DPRT = data; //send data to data port
	LCD_CPRT |= (1<<LCD_RS); //RS = 1 for data
	LCD_CPRT &= ~(1<<LCD_RW); //RW = 0 for write
	LCD_CPRT |= (1<<LCD_EN); //EN = 1 for H-to-L pulse
	_delay_us(1); //wait to make enable wide
	LCD_CPRT &= ~(1<<LCD_EN); //EN = 0 for H-to_L pulse
	_delay_us(100); //wait to make enable wide
}

void lcd_init()
{
	LCD_DDDR = 0xFF;
	LCD_CDDR = 0xFF;
	LCD_CPRT &=~(1<<LCD_EN); //LCD_EN = 0
	_delay_us(2000); //wait for init
	lcdCommanda(0x38); //inti. LCD 2 line, 5x7
	lcdCommanda(0x0E); //display on, cursor on
	lcdCommanda(0x01); //clear LCD
	_delay_us(2000); //wait
	lcdCommanda(0x06); //shift cursor right
}

void lcd_gotoxy(unsigned char x, unsigned char y)
{
	unsigned char firstCharAdr[] = {0x80, 0xC0};	//first character address within LCD
	lcdCommanda(firstCharAdr[y-1] + x -1);			//moves cursor in relation to first address
	_delay_us(100);									//delay
}

void lcd_print(char * str)
{
	unsigned char i = 0;
	while (str[i]!=0)						
	{
		lcdData(str[i]);							//output string one character at a time 
		i++;										//increment until end of string 
	}
}

//****************************************************************************
int main(void)
{
	DDRC &= ~(1<<PORTC0); //PC0 is analog input
		
	ADCSRA = 0x87; //set ADEN, ADC prescaler 128
	ADMUX = 0xC0; //select channel 0 (PC0)
	sei(); //enable interrupts (needed for timer overflow interrupt)
		
	//configure timer 1 to interrupt every second
	TCNT1 = 65536 - ((double)F_CPU/256); //overflow in 1 sec
	TCCR1A = 0; //normal mode
	TCCR1B = 4; //prescaler = 256
	TIMSK1  |= (1<<TOIE1); //interrupt on overflow
		
	while(1); //wait for interrupts
		
	return 0;
}
ISR(TIMER1_OVF_vect) //timer1 overflow ISR
{
	TCCR1B = 0; //stop timer 1
	TIFR1 = 1; //clear overflow flag
		
	int adc_temp;   //stores ADC temporarily
	float adc_float; //float for calculations
	int adc_temp_integer; //integer part
	int adc_temp_decimal; //decimal part
	
	//read ADC
	ADCSRA |= (1<<ADSC); //start conversion
	while((ADCSRA &(1<<ADIF)) == 0); //wait for conversion to finish
	adc_temp = ADC; //save ADC value
		
	adc_float = (float)adc_temp * (1.1 / 1024) / 0.01; //ADC value * resolution / scale factor of LM34 (10mV/deg F)
	adc_temp_integer = (int)adc_float; //integer part
	adc_float = adc_float - adc_temp_integer; //subtract integer part
	adc_temp_decimal = (int)(adc_float * 10); //decimal part
	
	char TempInteger[3]; //stores temperature to be displayed
	sprintf(TempInteger, "%d", adc_temp_integer); //integer part to string
	
	char TempDecimal[4]; //stores decimal part
	sprintf(TempDecimal, "%d�F\r\n", adc_temp_decimal); // %d displays integer value of decimal value
	
	lcd_init();						//intialize LCD
	lcd_gotoxy(1,1);				//go to address of first 8x1 chunk
	lcd_print("Temp: ");			//displays "Temp: "
	lcd_gotoxy(1,2);				//go to address of second 8x2 chunk
	for (int i = 0; i < 2; i++)
		lcdData(TempInteger[i]);	//display integer part of temperature
	lcd_print(".");					//diplay decimal point
	for (int i = 0; i < 3; i++)
		lcdData(TempDecimal[i]);	//display decimal part of temperature
	
	//re-configure timer 1 to interrupt every second
	TCNT1 = 65536 - ((double)F_CPU/256); //overflow in 1 sec
	TCCR1A = 0; //normal mode
	TCCR1B = 4; //prescaler = 256
		
	return;
}

